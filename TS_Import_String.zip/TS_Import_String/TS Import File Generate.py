from faker import Faker
from string import punctuation
import random
import string
import datetime
import openpyxl

def generate_sentences(num_sentences, locale='en_US'):
    """Generate a list of English sentences."""
    fake = Faker(locale)
    return [fake.sentence() for i in range(num_sentences)]

def encase_random_items(input_list):
    if len(input_list)!=0:
        output_list = input_list.copy()
        num_items_to_encase = random.randint(1, len(input_list)-1)
        indices_to_encase = random.sample(range(len(input_list)-1), num_items_to_encase)
        # Encase the selected items in braces
        for index in indices_to_encase:
            output_list[index] = f'{{{output_list[index]}}}'
        return " ".join(output_list)
    else:
        return ""

def string_cleanup(sentence):
    special_chars=set(punctuation)
    temp_sentence=sentence
    cleaned_sentence=""
    for i in temp_sentence:
        if i not in special_chars:
            cleaned_sentence=cleaned_sentence+i
    return cleaned_sentence

def create_excel_file(string_list):
    datestring = datetime.datetime.now()
    wb = openpyxl.Workbook()
    ws = wb.active
    filename="Import_Test_Strings_"+str((datestring.strftime("%Y_%b_%d_%H_%M_%S_%f")))+".xlsx"
    print("Generated Filename -",filename)
    
    alphabets=string.ascii_uppercase
    header_list=["UUID","English (US) [Primary]","Arabic","Chinese (Simplified)","Chinese (Traditional)","Dutch","English (UK)","French (Canada)","French (France)","French (Switzerland)","German","Greek","Hebrew","Italian","Japanese","Korean","Polish","Portuguese","Russian","Spanish","Swedish","Thai","Turkish","Description","Notes for Translator"]
    for i in range(len(header_list)):
        ws[alphabets[i]+"1"] = header_list[i]
    for i in alphabets[1:]:
        for j in range(len(string_list)):
            ws[i+str(j+2)]=string_list[j]
    wb.save(filename)


if __name__ == "__main__":
    count=int(input("Enter the number of strings to be generated \n"))
    encase=input("If you want to encase type 'Y' else 'N' \n")
    final_string_lst=[]
    strings=generate_sentences(num_sentences=count)
    if encase.upper()=="Y":
        for i in strings:
            final_string_lst.append(encase_random_items(i.split(" ")))
    else:
        final_string_lst=strings.copy()
    create_excel_file(final_string_lst)