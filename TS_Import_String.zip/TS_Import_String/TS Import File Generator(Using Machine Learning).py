from nltk.corpus import words
from keytotext import pipeline
from string import punctuation
import secrets
import random
import string
import datetime
import openpyxl

def get_random_word():
    #get a list of english words
    english_words = words.words()
    return secrets.choice(english_words)

def sentence_generation(keywords_list):
    #generate sentence using keytotext model
    """ Model Names - "k2t" , "k2t-base" , "mrm8488/t5-base-finetuned-common_gen" """
    nlp=pipeline("mrm8488/t5-base-finetuned-common_gen")
    return str(nlp(keywords_list))

def string_cleanup(sentence):
    #cleanup the generated sentences by removing the punctuations.
    special_chars=set(punctuation)
    temp_sentence=sentence
    cleaned_sentence=""
    for i in temp_sentence:
        if i not in special_chars:
            cleaned_sentence=cleaned_sentence+i
    return cleaned_sentence

def string_generation():
    keywords_list=[]
    while len(keywords_list)<5:
        choice_keyword=get_random_word()
        if choice_keyword not in keywords_list:
            keywords_list.append(choice_keyword)
        else:
            pass
    sentence=sentence_generation(keywords_list)
    final_senetence=string_cleanup(sentence)
    return final_senetence

def encase_random_items(input_list):
    if len(input_list)!=0:
        output_list = input_list.copy()
        num_items_to_encase = random.randint(1, len(input_list)-1)
        indices_to_encase = random.sample(range(len(input_list)-1), num_items_to_encase)
        # Encase the selected items in braces
        for index in indices_to_encase:
            output_list[index] = f'{{{output_list[index]}}}'
        return " ".join(output_list)
    else:
        return ""

def create_excel_file(string_list):
    datestring = datetime.datetime.now()
    wb = openpyxl.Workbook()
    ws = wb.active
    filename="Import_Test_Strings_"+str((datestring.strftime("%Y_%b_%d_%H_%M_%S_%f")))+".xlsx"
    print("Generated Filename -",filename)
    alphabets=string.ascii_uppercase
    header_list=["UUID","English (US) [Primary]","Arabic","Chinese (Simplified)","Chinese (Traditional)","Dutch","English (UK)","French (Canada)","French (France)","French (Switzerland)","German","Greek","Hebrew","Italian","Japanese","Korean","Polish","Portuguese","Russian","Spanish","Swedish","Thai","Turkish","Description","Notes for Translator"]
    for i in range(len(header_list)):
        ws[alphabets[i]+"1"] = header_list[i]
    for i in alphabets[1:]:
        for j in range(len(string_list)):
            ws[i+str(j+2)]=string_list[j]
    wb.save(filename)

if __name__ == "__main__":
    count=int(input("Enter the number of strings to be generated \n"))
    encase=input("If you want to encase type 'Y' else 'N' \n")
    string_list=[]
    for i in range(count):
        strings=string_generation()
        strings=string_cleanup(strings)
        if encase.upper()=="Y":
            encased_string=encase_random_items(list(strings.split(" ")))
            string_list.append(encased_string)
        else:
            string_list.append(strings)
    create_excel_file(string_list)